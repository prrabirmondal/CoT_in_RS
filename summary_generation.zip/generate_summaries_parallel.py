import pandas as pd
import ast
import torch
import os
import time
from transformers import AutoTokenizer, AutoModelForCausalLM
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

output_dir = "checkpoints"
if not os.path.exists(output_dir):
    os.makedirs(output_dir, exist_ok=True)
exit_after_minutes = 110  # Soft timeout before GPU limit
start_time = time.time()

embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

model_name = "Qwen/Qwen2.5-Coder-32B-Instruct"
tokenizer1 = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True, cache_dir="/hf_models/")
model1 = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype="auto", device_map="auto", trust_remote_code=True, cache_dir="/hf_models/")

tokenizer2 = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True, cache_dir="/hf_models/")
model2 = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype="auto", device_map="auto", trust_remote_code=True, cache_dir="/hf_models/")

df = pd.read_csv("/user_pref_master.csv")
df['has_next_movie'] = False
user_groups = df.groupby('user_id')

for user_id, group in user_groups:
    sorted_indices = group.sort_values(by='movie_id').index.tolist()
    for i, idx in enumerate(sorted_indices[:-1]):
        df.at[idx, 'has_next_movie'] = True

def compute_cosine_similarity(summary, next_likes_dict):
    try:
        next_likes_text = " ".join(next_likes_dict.values())
    except Exception:
        return 0.0
    embeddings = embedder.encode([summary, next_likes_text])
    sim = cosine_similarity([embeddings[0]], [embeddings[1]])
    return float(sim[0][0])

def query_model(prompt, model, tokenizer):
    messages = [{"role": "user", "content": prompt}]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
    model_inputs = tokenizer([text], return_tensors="pt").to(model.device)
    with torch.no_grad():
        generated_ids = model.generate(
            **model_inputs,
            max_new_tokens=150,
            do_sample=True,
            temperature=0.9,
            top_p=0.95
        )
    output_ids = generated_ids[0][len(model_inputs.input_ids[0]):].tolist()
    torch.cuda.empty_cache()
    try:
        index = len(output_ids) - output_ids[::-1].index(151668)
    except ValueError:
        index = 0
    content = tokenizer.decode(output_ids[index:], skip_special_tokens=True).strip("\n")
    return content

def generate_best_summary(row, model, tokenizer):
    likes_dict = ast.literal_eval(row['likes'])
    prev_summary = row['prev_summary']
    has_next_movie = row['has_next_movie']
    prompt = (
        f"Based on the following liked features:\n\n{likes_dict}"
        + (f" and {prev_summary}" if prev_summary else "") +
        "\n\nGenerate a refined, updated paragraph summarizing what this user generally prefers in movies.\n"
        "Ensure that this response is generated independently and does not rely on or get influenced by any previous summaries or responses."
        "Treat this as a standalone task with no prior context. Limit the summary to a max of 50 words"
    )
    candidates = []
    for _ in range(5):
        output = query_model(prompt, model, tokenizer)
        summary = output.split("features:")[-1].strip()
        next_likes_dict = None
        if has_next_movie:
            try:
                next_likes = df.loc[row.name+1]['likes']
                next_likes_dict = ast.literal_eval(next_likes)
                sim = compute_cosine_similarity(summary, next_likes_dict)
            except:
                sim = 0.0
        else:
            sim = 1.0
        candidates.append((summary, sim))
    best = max(candidates, key=lambda x: x[1])
    return best[0]

def process_user_rows(user_df, model, tokenizer):
    user_df = user_df.sort_values(by=['cluster_id', 'movie_id'])
    summary_memory = {}
    last_cluster = None
    pbar = tqdm(user_df.iterrows(), total=len(user_df), desc="Processing Clusters")
    for idx, row in pbar:
        if (time.time() - start_time) > exit_after_minutes * 60:
            logging.warning("Time limit reached. Exiting early.")
            break
        key = (row['user_id'], row['cluster_id'])
        out_path = os.path.join(output_dir, f"user_{key[0]}_cluster_{key[1]}.csv")
        if os.path.exists(out_path):
            logging.info(f"Skipping already processed: {key}")
            continue
        if last_cluster is not None and last_cluster != key:
            logging.info(f"Finished processing user {last_cluster[0]}, cluster {last_cluster[1]} — saving to CSV.")
            df[(df['user_id'] == last_cluster[0]) & (df['cluster_id'] == last_cluster[1])].to_csv(
                os.path.join(output_dir, f"user_{last_cluster[0]}_cluster_{last_cluster[1]}.csv"), index=False)
            summary_memory[key] = None
        prev = summary_memory.get(key, None)
        df.at[idx, 'prev_summary'] = prev if prev else ""
        new_summary = generate_best_summary(row, model, tokenizer)
        df.at[idx, 'best_summary'] = new_summary
        summary_memory[key] = new_summary
        last_cluster = key
    if last_cluster:
        df[(df['user_id'] == last_cluster[0]) & (df['cluster_id'] == last_cluster[1])].to_csv(
            os.path.join(output_dir, f"user_{last_cluster[0]}_cluster_{last_cluster[1]}.csv"), index=False)

df = df.sort_values(by=["user_id", "cluster_id", "movie_id"]).reset_index(drop=False)
df['prev_summary'] = None
df['best_summary'] = None

user_ids = df['user_id'].unique()
users1 = set(user_ids[::2])
users2 = set(user_ids[1::2])

with ThreadPoolExecutor(max_workers=2) as executor:
    future1 = executor.submit(process_user_rows, df[df['user_id'].isin(users1)], model1, tokenizer1)
    future2 = executor.submit(process_user_rows, df[df['user_id'].isin(users2)], model2, tokenizer2)
    future1.result()
    future2.result()

# Save final output
df[['user_id', 'cluster_id', 'movie_id', 'best_summary']].to_csv("user_summaries_with_context.csv", index=False)
